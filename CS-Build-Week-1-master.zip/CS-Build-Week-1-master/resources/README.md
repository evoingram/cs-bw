# Additional Resources

* [Web](web/)
* [iOS](ios/)
* [Python](python/)--not recommended
