# General Resources
1.

# Track-Specific Resources


## Full-Stack Web
Although you are welcome to explore and use other libraries, below are some
resources to help get you started on the project using React.

1. [Learn about HTML canvas and screen buffers](../../resources/canvas-buffer)
2. [Learn about animating a canvas in a React component](../../resources/canvas)
3. [Consider implementing Game of Life with a Canvas](../../resources/life-canvas)
4. [Consider implementing Game of Life with a collection of React components](../../resources/simple-components)
5. [Readme with information on how to perform common React tasks](../../resources/react-setup)


## Data Science



## iOS



## Android
